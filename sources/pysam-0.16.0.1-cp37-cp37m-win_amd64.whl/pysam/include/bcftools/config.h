/* empty config.h created by pysam */
/* conservative compilation options */
