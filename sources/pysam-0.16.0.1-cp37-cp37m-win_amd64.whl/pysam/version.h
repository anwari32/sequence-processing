// Version information used while compiling samtools, bcftools, and htslib

#define SAMTOOLS_VERSION "1.10 (pysam)"
#define BCFTOOLS_VERSION "1.10.2 (pysam)"
#define HTS_VERSION_TEXT "1.10.2 (pysam)"
